<?php 
session_start();
try {
    $connection = new PDO(
        'mysql:host=tutorial-db-instance.ct8rahpwhetc.us-east-1.rds.amazonaws.com;dbname=sample;port=3306',
        'tutorial_user',
        'coolbeans!'
    );
} catch (PDOException $e) {
    die("Error connecting to MySQL: {$e->getMessage()}");
}
print_r($_POST);
if ($_POST["word6"]){
    $guess1 = $_POST["word1"];
    $guess2 = $_POST["word2"];
    $guess3 = $_POST["word3"];
    $guess4 = $_POST["word4"];
    $guess5 = $_POST["word5"];
    $guess6 = $_POST["word6"];
    $query = "SELECT default-time-zone='chicago'";
    $statement=$connection->prepare($query);
    $statement->execute();
    $query = "SELECT TIME_FORMAT('19:30:10', '%H %i %s');";
    $statement=$connection->prepare($query);
    $statement->execute();
    $query = "INSERT INTO `wordle_rzp`.`past_games`(time, guessone, guesstwo, guessthree, guessfour, guessfive, guesssix) VALUES (now(), ?, ?, ?, ?, ?, ?)";
    $statement=$connection->prepare($query);
    $statement->bindParam(1,$guess1);
    $statement->bindParam(2, $guess2);
    $statement->bindParam(3, $guess3);
    $statement->bindParam(4, $guess4);
    $statement->bindParam(5, $guess5);
    $statement->bindParam(6, $guess6);
    // $statement->bindParam(7, $_SESSION["username"]);
    $statement->execute();
}

    
// echo "<meta http-equiv=\"refresh\" content=\"0;URL='https://www.bdpastudents.com/code/run/c3372c0/Assignment14/wordle.php'\" />";

