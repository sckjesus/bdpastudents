<?php
session_start();
session_destroy();
echo   "<meta http-equiv=\"refresh\" content=\"0;URL='https://www.bdpastudents.com/code/run/c3372c0/Assignment14/login.html'\" />" ;   